#include "../../../Header/Strategy/Concrete/StrategyB.h"
#include "../../../Header/Manager/Concrete/ChargeableManager.h"
#include "../../../Header/Manager/Concrete/SceneManager.h"
#include "../../../Header/Chargeable/Concrete/Robot.h"
#include "../../../Header/Chargeable/Concrete/Vehicle.h"
void StrategyB::UpdateMovement(Chargeable* _chargeable)
{
}