#ifndef _STRATEGY_TYPE_H_
#define _STRATEGY_TYPE_H_

enum class StrategyType
{
	A,
	B,
	C
};

#endif