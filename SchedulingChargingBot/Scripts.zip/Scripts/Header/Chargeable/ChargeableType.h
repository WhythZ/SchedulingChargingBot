#ifndef _CHARGEABLE_TYPE_H_
#define _CHARGEABLE_TYPE_H_

enum class ChargeableType
{
	None,
	Robot,
	Vehicle,
	Battery
};

#endif